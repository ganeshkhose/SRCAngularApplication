import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous',
  templateUrl: './marvellous.component.html',
  styleUrls: ['./marvellous.component.css']
})
export class MarvellousComponent implements OnInit 
{

  public Technology = "Node.js"
  currentCustomer = 'Maria';
  constructor() { }

  ngOnInit() {
  }

  fun()
  {
    return "Learn "+ this.Technology;
  }
}
