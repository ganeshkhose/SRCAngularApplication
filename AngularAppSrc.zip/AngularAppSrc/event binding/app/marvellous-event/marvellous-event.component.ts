import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous-event',
  templateUrl: './marvellous-event.component.html',
  styleUrls: ['./marvellous-event.component.css']
})
export class MarvellousEventComponent 
{

  public str="";
  public str1="";
  public str2="";


  // It is condiderd as our event handler
  public MarvellousEvent()
  {
    console.log('Button pressed');      
  }

  public MarvellousNewEvent()
  {
    this.str="Button clicked";  
  }

  public MarvellousEventInfo(value:any)
  {
    console.log(value);
  }

  public void()
  {
    this.str1="Education is imp for better tommorow";
  }

  public void1()
  {
    return "Education is imp for better tommorow";
  }
}
