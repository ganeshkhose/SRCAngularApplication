import { Component } from '@angular/core';

@Component({
  selector: 'app-invalidpage',
  templateUrl: './invalidpage.component.html',
  styleUrls: ['./invalidpage.component.css']
})
export class InvalidpageComponent {

}
