import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SubjectsComponent } from './subjects/subjects.component';
import { BatchesComponent } from './batches/batches.component';
import { InvalidpageComponent } from './invalidpage/invalidpage.component';
import { AppComponent } from './app.component';

//Array of Routes in application
const routes: Routes = [
  {path : 'batches', component:BatchesComponent},
{path : 'subjects' ,component:SubjectsComponent},
//Add on default path
{ path: '', component:BatchesComponent},
// It is our Widcard component
{path : '**', component:InvalidpageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
