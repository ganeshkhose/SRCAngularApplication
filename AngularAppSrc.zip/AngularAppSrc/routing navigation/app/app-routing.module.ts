import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SubjectComponent } from './subject/subject.component';
import { BatchesComponent } from './batches/batches.component';
const routes: Routes = [
  {path : 'batches', component:BatchesComponent},
  {path : 'subjects' ,component:SubjectComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
