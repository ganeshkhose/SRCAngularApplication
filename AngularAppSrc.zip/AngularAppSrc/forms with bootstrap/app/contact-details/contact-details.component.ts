import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.css']
})
export class ContactDetailsComponent
{
  public States=['Maharastra','karnataka','UttarPradesh','MadhyaPradesh','Uttarkhand','Rajyasthan','Bihar','Goa','Tamilnadu','Telangana','Andrapradesh','Delhi','Kerala','Chattishgarh','Jharkhand','Orisha','Gujarat','Jammu and Kashmir','Punjab','Haryana','Himachal Pradesh']

  public batches=['Pre-Placement Activity','Logic Building','Angular','Python','Industrial Project Development']
}
