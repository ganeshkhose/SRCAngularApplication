import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous-style',
  templateUrl: './marvellous-style.component.html',
  styleUrls: ['./marvellous-style.component.css']
})
export class MarvellousStyleComponent 
{
  public IsSet=true;
  public MyColor="blue";
  
  
}
